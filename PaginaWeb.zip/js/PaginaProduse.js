function returneazaProdus() {
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      var id = urlParams.get('idProdus');

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/utilizator/primesteproduse/${id}`,
            {
                method: "GET"
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 206){
                    console.log("Completeaza toate campurile!")
                }else if(raspuns.status == 404){
                    console.log("Produsul nu a fost gasit!")
                }else if(raspuns.status == 500){
                    console.log("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (raspuns) { 
                document.getElementById("numeProdus").innerHTML = raspuns.nume
                document.getElementById("descriere").innerHTML = raspuns.descriere
                document.getElementById("categorie").innerHTML = "Categorie: " + raspuns.categorie
                document.getElementById("distribuitor").innerHTML = "Distribuitor: " + raspuns.distribuitor
                document.getElementById("pret").innerHTML = raspuns.pret + " Lei"
                document.getElementById("poza").src = raspuns.poza
            })
            .catch((raspuns) => {
            });
}