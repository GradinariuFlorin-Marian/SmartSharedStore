function trimiteCatalog() {
      var load = {
          token: getCookie('token'),
          numeCatalog: document.getElementById('numeCatalog').value,
          linkCatalog: document.getElementById('linkCatalog').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/cataloage/adaugacatalog`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Produsul a fost adaugat!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });
}

function stergeCatalog(produs) {
      var load = {
          token: getCookie('token'),
          idCatalog: produs
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/cataloage/stergecatalog`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                   alert("Produs a fost eliminat!");
                   returneazaProduse();
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Produsul nu a fost gasit!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}


function returneazaCataloage() {
   var load = {
          token: getCookie('token')
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/cataloage/returneazacataloage`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Nu a fost gasit!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                 table.innerHTML = "";
                   code.map(catalog => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = catalog.id;
                     let nume = rand.insertCell(1);
                     nume.innerHTML = catalog.numeCatalog;

                     let operatie = rand.insertCell(2);
                     operatie.innerHTML += '<input type="button" name="Sterge catalog" id="back" value="Sterge catalog"    onClick="stergeCatalog(\''+catalog.id+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}