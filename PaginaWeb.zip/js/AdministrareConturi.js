function adaugaContAdministrator() {
	  var load = {
            token: getCookie('token'),
            nume: document.getElementById('nume').value,
            parola: document.getElementById('parola').value
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/adaugacontadmin`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Contul a fost adaugat!");
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function stergeContAdministrator(numeAdministrator) {
	  var load = {
            token: getCookie('token'),
            nume: numeAdministrator,
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/stergecontadmin`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Contul a fost sters!");
                    returneazaConturi();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Contul nu a fost gasit!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });

}

function returneazaConturi() {
   var load = {
          token: getCookie('token')
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazaconturi`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Contul nu a fost gasit!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                 table.innerHTML = "";
                   code.map(comanda => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = comanda.id;
                     let email = rand.insertCell(1);
                     email.innerHTML = comanda.nume;

                     let status = rand.insertCell(2);
                     status.innerHTML += '<input type="button" name="Sterge cont" id="back" value="Sterge cont"    onClick="stergeContAdministrator(\''+comanda.nume+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function actualizeazaParola() {
   var load = {
          token: getCookie('token'),
          parola: document.getElementById('parola').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/actualizeazaparola`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Parola actualizata!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Contul nu a fost gasit!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}