function actualizeazaStatus() {
    var status = "";
    if(document.getElementById('activat').checked) {
        status = "1";
    }else{
        status = "0";
    }
	  var payload = {
            token: getCookie('token'),
            mentenanta: status,
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/modmentenanta`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(payload),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns;
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) {
                   alert("Statusul sistemul de mentenanta a fost actualizat!");
            })
            .catch((raspuns) => {
            });
}