function trimiteProdus() {
      var load = {
          token: getCookie('token'),
          nume: document.getElementById('nume').value,
          pret: document.getElementById('pret').value,
          distribuitor: document.getElementById('distribuitor').value,
          cantitate: document.getElementById('cantitate').value,
          descriere: document.getElementById('descriere').value,
          categorie: document.getElementById('categorie').value,
          poza: document.getElementById('poza').value,
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/adaugaprodus`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Produsul a fost adaugat!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });
}

function adaugaProdusInRecomandate(idProdus) {
      var load = {
          token: getCookie('token'),
          id: idProdus
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/adaugaprodusinrecomandate`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Produs adaugat in recomandate!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });
}

function stergeProdus(produs) {
      var load = {
          token: getCookie('token'),
          idProdus: produs
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/stergeprodus`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                   alert("Produs a fost eliminat!");
                   returneazaProduse();
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Produsul nu a fost gasit!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function stergeProdusDinRecomandate(produs) {
      var load = {
          token: getCookie('token'),
          idProdus: produs
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/stergeprodusdinrecomandate`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                   alert("Produs eliminat din recomandate!");
                   returneazaProduseDinRecomandate();
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Produsul nu a fost gasit in lista de recomandate!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaProduse() {
   var load = {
          token: getCookie('token'),
          numeProduse: document.getElementById('numeProdus').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazaproduse`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Nu a fost gasit!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                 table.innerHTML = "";
                   code.map(produs => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = produs.id;
                     let nume = rand.insertCell(1);
                     nume.innerHTML = produs.nume;
                     let distribuitor = rand.insertCell(2);
                     distribuitor.innerHTML = produs.distribuitor;
                     let categorie = rand.insertCell(3);
                     categorie.innerHTML = produs.categorie;

                     let operatie = rand.insertCell(4);
                     operatie.innerHTML += '<input type="button" name="Sterge produs" id="back" value="Sterge produs"    onClick="stergeProdus(\''+produs.id+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaProduseDinRecomandate() {
   var load = {
          token: getCookie('token'),
          numeProduse: document.getElementById('numeProdus').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazaprodusedinrecomandate`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Produsele nu au fost gasite!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                 table.innerHTML = "";
                   code.map(produs => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = produs.id;
                     let nume = rand.insertCell(1);
                     nume.innerHTML = produs.nume;
                     let distribuitor = rand.insertCell(2);
                     distribuitor.innerHTML = produs.distribuitor;
                     let categorie = rand.insertCell(3);
                     categorie.innerHTML = produs.categorie;

                     let operatie = rand.insertCell(4);
                     operatie.innerHTML += '<input type="button" name="Sterge produs" id="back" value="Sterge produs"    onClick="stergeProdus(\''+produs.id+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaProduse() {
   var load = {
          token: getCookie('token'),
          numeProduse: document.getElementById('numeProdus').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazaproduse`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Produsele nu au fost gasite!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                 table.innerHTML = "";
                   code.map(produs => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = produs.id;
                     let nume = rand.insertCell(1);
                     nume.innerHTML = produs.nume;
                     let distribuitor = rand.insertCell(2);
                     distribuitor.innerHTML = produs.distribuitor;
                     let categorie = rand.insertCell(3);
                     categorie.innerHTML = produs.categorie;

                     let operatie = rand.insertCell(4);
                     operatie.innerHTML += '<input type="button" name="Sterge produs" id="back" value="Adauga produs in recomandate"    onClick="adaugaProdusInRecomandate(\''+produs.id+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaComenzi() {
   var load = {
          token: getCookie('token')
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazacomenzi`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Comanda nu a fost gasita!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                   code.map(comanda => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = comanda.id;
                     let email = rand.insertCell(1);
                     email.innerHTML = comanda.email;
                     let adresa = rand.insertCell(2);
                     adresa.innerHTML = comanda.adresa;
                     let pret = rand.insertCell(3);
                     pret.innerHTML = comanda.pretTotal;
                     let platitPrin = rand.insertCell(4);
                     platitPrin.innerHTML = comanda.platitPrin;
                     let telefon = rand.insertCell(5);
                     telefon.innerHTML = comanda.numarTelefon;

                     let status = rand.insertCell(6);
                     var selectList = document.createElement("select");
                     status.appendChild(selectList);

                     selectList.addEventListener("change",function(){
                            schimbaStatusul(comanda.id, this.options[this.selectedIndex].text);
                        });

                     selectList.appendChild(new Option(comanda.statusComanda, comanda.id));
                     if(comanda.statusComanda !== "In pregatire"){
                     selectList.appendChild(new Option("In pregatire", comanda.id));
                     }
                     if(comanda.statusComanda !== "Trimisa"){
                     selectList.appendChild(new Option("Trimisa", comanda.id));
                     }
                     if(comanda.statusComanda !== "Finalizata"){
                     selectList.appendChild(new Option("Finalizata", comanda.id));
                     }
                     if(comanda.statusComanda !== "Anulata"){
                     selectList.appendChild(new Option("Anulata", comanda.id));
                     }

                     let detalii = rand.insertCell(7);
                     detalii.innerHTML += '<input type="button" name="Detalii comanda" id="back" value="Detalii comanda"    onClick="window.open(\'https://smart-shared-store-yycubv.web.app/ProduseComenzi?idComanda='+comanda.id+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function schimbaStatusul(id, status) {
   var load = {
          token: getCookie('token'),
          idComanda: id,
          statusComanda: status
        };
        console.log(JSON.stringify(load));

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/actualizeazastatuscomanda`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Nu a fost gasit!")
                }else if(raspuns.status == 400){
                    alert("Eroare!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 alert("Status actualizat!");

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaComenziFiltrate() {
   var stat = document.getElementById('status');
   var fil = document.getElementById('filtru');
   var load = {
          token: getCookie('token'),
          status: stat.options[stat.selectedIndex].text,
          filtru: fil.options[fil.selectedIndex].text,
          valoareFiltru: document.getElementById('valoareFiltru').value
        };
        console.log(JSON.stringify(load));

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazacomenzifiltrate`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Nu a fost gasit!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                 table.innerHTML = "";
                   code.map(comanda => {
                     let rand = table.insertRow();
                     let id = rand.insertCell(0);
                     id.innerHTML = comanda.id;
                     let email = rand.insertCell(1);
                     email.innerHTML = comanda.email;
                     let adresa = rand.insertCell(2);
                     adresa.innerHTML = comanda.adresa;
                     let pret = rand.insertCell(3);
                     pret.innerHTML = comanda.pretTotal;
                     let platitPrin = rand.insertCell(4);
                     platitPrin.innerHTML = comanda.platitPrin;
                     let telefon = rand.insertCell(5);
                     telefon.innerHTML = comanda.numarTelefon;

                     let status = rand.insertCell(6);
                     var selectList = document.createElement("select");
                     status.appendChild(selectList);

                     selectList.addEventListener("change",function(){
                            schimbaStatusul(comanda.id, this.options[this.selectedIndex].text);
                        });

                     selectList.appendChild(new Option(comanda.statusComanda, comanda.id));
                     if(comanda.statusComanda !== "In pregatire"){
                     selectList.appendChild(new Option("In pregatire", comanda.id));
                     }
                     if(comanda.statusComanda !== "Trimisa"){
                     selectList.appendChild(new Option("Trimisa", comanda.id));
                     }
                     if(comanda.statusComanda !== "Finalizata"){
                     selectList.appendChild(new Option("Finalizata", comanda.id));
                     }
                     if(comanda.statusComanda !== "Anulata"){
                     selectList.appendChild(new Option("Anulata", comanda.id));
                     }

                     let detalii = rand.insertCell(7);
                     detalii.innerHTML += '<input type="button" name="Detalii comanda" id="back" value="Detalii comanda"    onClick="window.open(\'https://smart-shared-store-yycubv.web.app/ProduseComenzi?idComanda='+comanda.id+'\')" />';

                  });

            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaComanda() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    var idComanda = urlParams.get('idComanda');

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazacomandacuproduse/${idComanda}`,
            {
                headers: {
                'token': getCookie('token')
                         },
                method: "GET"
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 204){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 404){
                    alert("Comanda nu a fost gasita!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) { 
                 const table = document.getElementById("tablearea");
                     let produse = code.produseInCos;
                     document.getElementById("informatii").innerHTML = "ID Comanda: " + idComanda;
                     const iterator = produse.values();
                        for (const value of iterator) {
                                var produseJs = JSON.parse(value);
                                let rand = table.insertRow();
                                let id = rand.insertCell(0); 
                                id.innerHTML = produseJs.id;
                                let poza = rand.insertCell(1); 
                                poza.innerHTML += '<img src=\''+produseJs.poza+'\')" height=75px width=75px/>';
                                let nume = rand.insertCell(2); 
                                nume.innerHTML = produseJs.nume;
                                let distribuitor = rand.insertCell(3); 
                                distribuitor.innerHTML = produseJs.distribuitor;
                                let cantitate = rand.insertCell(4); 
                                cantitate.innerHTML = produseJs.cantitate;
                        }
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function modificaProdus() {
      var load = {
          token: getCookie('token'),
          id: document.getElementById('nume').value,
          valoare: document.getElementById('pret').value,
          valoareNoua: document.getElementById('distribuitor').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/modificaprodus`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Produsul a fost actualizat!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });
}