function verificaContul() {
	  var load = {
            token: getCookie('token'),
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/verificaretoken`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((response) => {
                if (response.status == 200) {
                    return response;
                }else if(response.status == 206){
                    alert("No content")
                }else if(response.status == 401){
                     window.history.pushState('Admin', 'Title', "/");
        			 window.history.go();
                }else if(response.status == 404){
                     window.history.pushState('Admin', 'Title', "/");
        			 window.history.go();
                }else if(response.status == 500){
                    alert("Serverul nu raspunde!")
                }
                throw response;
            })
            .catch((response) => {
            });
}

function doarPunctSiNumar(txt, event) {
        var charCode = (event.which) ? event.which : event.keyCode
        if (charCode == 46) {
            if (txt.value.indexOf(".") < 0)
                return true;
            else
                return false;
        }

        if (txt.value.indexOf(".") > 0) {
            var txtlen = txt.value.length;
            var dotpos = txt.value.indexOf(".");
            if ((txtlen - dotpos) > 2)
                return false;
        }

        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    }


