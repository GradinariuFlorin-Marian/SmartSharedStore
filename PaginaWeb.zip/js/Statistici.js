function returneazaStatistici() {
      var load = {
          token: getCookie('token')
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/returneazastatistici`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 400){
                    alert("Structura gresita!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (code) {
            	   const table = document.getElementById("tablearea");
                   code.map(produs => {
					   let rand = table.insertRow();
					   let nume = rand.insertCell(0);
					   nume.innerHTML = produs.numeProdus;
					   let categorie = rand.insertCell(1);
					   categorie.innerHTML = produs.categorie;
					   let distribuitor = rand.insertCell(2);
					   distribuitor.innerHTML = produs.distribuitor;
					   let produse = rand.insertCell(3);
					   produse.innerHTML = produs.produseVandute;
					   let accesari = rand.insertCell(4);
					   accesari.innerHTML = produs.accesari;
					   let cupoane = rand.insertCell(5);
					   cupoane.innerHTML = produs.cupoaneDeReducereUtilizate;
                   });
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

function returneazaStatisticiPrimare() {
      var load = {
          token: getCookie('token')
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/statisticiaplicatie`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load)
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.json();
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 400){
                    alert("Structura gresita!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul are probleme!")
                }
                throw raspuns;
            })
            .then(function (raspuns) {
                   document.getElementById("conturi").innerHTML = "Conturi create: " + raspuns.conturi
                   document.getElementById("produse").innerHTML = "Produse adaugate: " + raspuns.produse
                   document.getElementById("produseVandute").innerHTML = "Produse vandute: " + raspuns.produseVandute
            })
            .catch((raspuns) => {
                console.log("BAD", raspuns);
            });
}

