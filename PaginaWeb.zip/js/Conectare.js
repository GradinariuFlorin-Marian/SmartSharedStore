function conectare() {
        var load = {
            nume: document.getElementById('nume').value,
            parola: document.getElementById('parola').value
        };
        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/conectare`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    return raspuns.text();
                }else if(raspuns.status == 206){
                    alert("No content")
                }else if(raspuns.status == 401){
                    alert("Unauthorized")
                }else if(raspuns.status == 404){
                    alert("Not found!")
                }
                throw raspuns;
            })
            .then(function (code) {
                 setCookie("token", code, 14);
                 window.history.pushState('Admin', 'Title', "/Acasa");
                 window.history.go();

            })
            .catch((response) => {
            });
}

function validate($data) {
    if ($data === 1) {
        window.history.pushState('Admin', 'Title', "/Home.html");
        window.history.go();
    }
}

function rememberMe() {
    var check = document.getElementById("remember_me");
    if (check.checked) {
        localStorage.setItem("Check", "1");
    } else {
        localStorage.setItem("Check", "0");
    }
}
function removeLogin() {
    sessionStorage.removeItem("AdminUser");
    sessionStorage.removeItem("AdminToken");
    window.history.pushState('Admin', 'Title', "/Login");
    window.history.go();
}