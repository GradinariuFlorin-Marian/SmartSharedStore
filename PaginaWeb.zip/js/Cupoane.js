function adaugaCuponReducere() {
      var load = {
          token: getCookie('token'),
          idProdus: document.getElementById('idProdus').value,
          cod: document.getElementById('cod').value,
          sumaRedusa: document.getElementById('suma').value
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/adaugacodreducereglobal`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Codul de reducere a fost adaugat!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul nu raspunde!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });
}

function stergeCuponReducere() {
      var load = {
          token: getCookie('token'),
          cod: document.getElementById('cod').value,
        };

        fetch(
            `https://smartsharedstore-11.lm.r.appspot.com/administrare/stergecodreducereglobal`,
            {
                headers: new Headers(),
                method: "POST",
                body: JSON.stringify(load),
            }
        )
            .then((raspuns) => {
                if (raspuns.status == 200) {
                    alert("Codul de reducere a fost eliminat!")
                }else if(raspuns.status == 401){
                    alert("Nu ai permisiune!")
                }else if(raspuns.status == 206){
                    alert("Completeaza toate campurile!")
                }else if(raspuns.status == 500){
                    alert("Serverul nu raspunde!")
                }
                throw raspuns;
            })
            .catch((raspuns) => {
            });
}